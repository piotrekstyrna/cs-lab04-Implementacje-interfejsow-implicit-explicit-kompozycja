﻿using System.Text;
using ver1;
using static ver1.IDevice;
using static ver1.IDocument;

namespace Zadanie1 {
    public class Copier : BaseDevice, IPrinter, IScanner {
        public int PrintCounter { get; private set; }
        public int ScanCounter { get; private set; }
        public int Counter { get; private set; }

        static string GetPrintLog(IDocument document) {
            var outputLog = new StringBuilder();
            GetDate(outputLog);
            outputLog.Append(" Print: ");

            if (document != null)
                outputLog.Append(document.GetFileName());
            return outputLog.ToString();
        }

        static void GetDate(StringBuilder outputLog) {
            var date = DateTime.Now;
            outputLog.Append(date.ToString("dd'.'MM'.'yyyy"));
            outputLog.Append(' ');
            outputLog.Append(date.ToString("HH:mm:ss"));
        }

        public void PowerOn()
        {
            if (state == State.on)
                return;

            Counter++;
            base.PowerOn();
        }

        public void PowerOff()
        {
            if (state == State.off)
                return;

            base.PowerOff();
        }

        public void Print(in IDocument document) {
            if(state == State.off)
                return;

            var outputLog = GetPrintLog(document);
            PrintCounter++;
            Console.WriteLine(outputLog);
        }

        public void Scan(out IDocument document, FormatType formatType = FormatType.JPG) {
            if (state == State.off) {
                document = null;
                return;
            }

            var outputLog = GetScanLog(formatType);
            ScanCounter++;
            document = null;
            Console.WriteLine(outputLog);
        }

        public void ScanAndPrint() {
            if (state == State.off)
                return;

            Scan(out IDocument scannedDoc);
            Print(scannedDoc);
        }

        string GetScanLog(FormatType format)
        {
            var outputLog = new StringBuilder();
            GetDate(outputLog);
            outputLog.Append(" Scan: ");
            outputLog.Append(GetScanName(format));
            return outputLog.ToString();
        }

        string GetScanName(FormatType format)
        {
            switch (format)
            {
                case FormatType.PDF:
                    return $"PDFScan{ScanCounter}.pdf";
                case FormatType.TXT:
                    return $"TextScan{ScanCounter}.txt";
                case FormatType.JPG:
                    return $"ImageScan{ScanCounter}.jpg";
            }
            return string.Empty;
        }
    }
}
