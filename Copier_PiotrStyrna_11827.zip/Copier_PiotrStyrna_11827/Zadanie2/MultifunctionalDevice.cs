﻿using ver1;

namespace Zadanie2
{
    class MultifunctionalDevice : BaseDevice, IScanner, IPrinter, IFax {
        IScanner scanner;
        IPrinter printer;
        IFax fax;

        public MultifunctionalDevice(IScanner scanner, IPrinter printer) {
            this.scanner = scanner;
            this.printer = printer;
        }

        public void Scan(out IDocument document, IDocument.FormatType formatType) {
            if (state == IDevice.State.off) {
                document = null;
                return;
            }

            scanner.Scan(out IDocument scannedDocument, formatType);
            document = scannedDocument;
        }

        public void Print(in IDocument document) {
            if(state == IDevice.State.off)
                return;

            printer.Print(document);
        }

        public void Fax(in IDocument transferred) {
            if (state == IDevice.State.off)
                return;
            
            printer.Print(transferred);
        }

        public void PowerOn()
        {
            if (state == IDevice.State.on)
                return;

            base.PowerOn();
        }

        public void PowerOff()
        {
            if (state == IDevice.State.off)
                return;

            base.PowerOff();
        }
    }
}
